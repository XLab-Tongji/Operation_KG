cd Model1
python log_key_LSTM_train.py
cd ..
cd Model2
python variable_LSTM_train.py
cd ..
python log_predict.py