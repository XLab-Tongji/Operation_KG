package service.LogAnalysis.java.src;

import java.io.*;


public class deeplog {
    public static String predict() throws Exception {
        String detect_file = "detect.log";
        String use_model2 = "1";
        System.out.println("\nExecuting python script file now.");
        try {
            File directory = new File("");//参数为空
            String courseFile = directory.getCanonicalPath() ;
//            System.out.println(courseFile);
            String cmds = String.format("python "+courseFile+"/src/main/java/service/LogAnalysis/java/deeplog_java.py %s %s",
                    detect_file,use_model2);
            //python E:\git\Operation_KG\Backend\src\main\java\service.LogAnalysis\java\deeplog_java.py detect.log 1
            File file=new File(courseFile+"/src/main/java/service/LogAnalysis");
            Process proc = Runtime.getRuntime().exec(cmds,null,file);
            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line,fin = null;
            while ((line = in.readLine()) != null) {
//                System.out.println(line);
                fin=line;
            }
            String result=fin.split(" ")[2];
            in.close();
            proc.waitFor();
            return result;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "error";
    }
}
