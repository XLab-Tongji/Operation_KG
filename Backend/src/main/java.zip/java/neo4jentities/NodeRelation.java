package neo4jentities;

public class NodeRelation {
}
