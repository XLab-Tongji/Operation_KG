package neo4jentities;

import java.util.List;

public class LineResult {
    List<Node> nodesrelation;

    public List<Node> getNodesrelation() {
        return nodesrelation;
    }

    public void setNodesrelation(List<Node> nodesrelation) {
        this.nodesrelation = nodesrelation;
    }
}
